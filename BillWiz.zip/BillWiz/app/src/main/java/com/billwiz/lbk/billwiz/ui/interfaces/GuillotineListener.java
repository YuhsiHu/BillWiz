package com.billwiz.lbk.billwiz.ui.interfaces;

/**
 * Created by Dmytro Denysenko on 5/6/15.
 */

public interface GuillotineListener {
    void onGuillotineOpened();
    void onGuillotineClosed();
}
