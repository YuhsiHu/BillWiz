package com.billwiz.lbk.billwiz.model;

/**
 * Created by Weiping on 2016/1/21.
 */

public class BillWiz {

    public static String APPLICATION_ID = "d43b85d21f5856a3e1c21a2db5dd3240";

}
